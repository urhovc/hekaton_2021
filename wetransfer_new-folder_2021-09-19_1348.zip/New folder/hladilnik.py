from PyQt6.QtWidgets import * # QApplication, QWidget, QPushButton, QLabel, QLineEdit
from PyQt6.QtGui import * # QIcon, QFont, QPixmap
from PyQt6.QtCore import * #
from PyQt6 import QtCore, QtWidgets
import sqlite3
import sys
import os

# Handle high resolution displays:
if hasattr(QtCore.Qt, 'AA_EnableHighDpiScaling'):
    QtWidgets.QApplication.setAttribute(QtCore.Qt.AA_EnableHighDpiScaling, True)
if hasattr(QtCore.Qt, 'AA_UseHighDpiPixmaps'):
    QtWidgets.QApplication.setAttribute(QtCore.Qt.AA_UseHighDpiPixmaps, True)

class Window(QWidget):
    def __init__(self):
        super(Window, self).__init__()

        self.setWindowTitle("Handy Meal")
        self.setWindowIcon(QIcon(""))
        self.setGeometry(500,300, 700,400)
        self.setStyleSheet("background-color: #505050")

        font = QFont("OCR A Extended")
        font.setPointSize(20)
        font.setBold(False)

        font1 = QFont("OCR A Extended")
        font1.setPointSize(10)
        font1.setBold(False)

        font2 = QFont("OCR A Extended")
        font2.setPointSize(12)
        font2.setBold(False)

        font3 = QFont("OCR A Extended")
        font3.setPointSize(11)
        font3.setBold(False)

        font4 = QFont("OCR A Extended")
        font4.setPointSize(8)
        font4.setBold(False)

        ##############################################################################################################################################################################


        self.label = QLabel("Handy Meal", self)
        self.label.setFont(font)
        self.label.setGeometry(40,30, 232,30)
        self.label.setStyleSheet("color: white")

        self.label1 = QLabel("your friend in kitchen", self)
        self.label1.setFont(font1)
        self.label1.setGeometry(41,60, 200,20)
        self.label1.setStyleSheet("color: white")

        self.label2 = QLabel("Do you want to reduce the\nfood you throw away? Do\nyou need recipes depending\non your lifestyle? Can't\nkeep track of what's in your\nfridge? We got a solution\nfor that.", self)
        self.label2.setFont(font1)
        self.label2.setGeometry(40,100, 300,100)
        self.label2.setStyleSheet("color: white")

        self.label3 = QLabel("LIFESTYLE:", self)
        self.label3.setFont(font2)
        self.label3.setGeometry(354,33, 100,20)
        self.label3.setStyleSheet("color: white")

        self.label4 = QLabel("RESOURCES:", self)
        self.label4.setFont(font2)
        self.label4.setGeometry(354,120, 100,20)
        self.label4.setStyleSheet("color: white")

        self.label5 = QLabel("MEALS:", self)
        self.label5.setFont(font2)
        self.label5.setGeometry(354,180, 60,20)
        self.label5.setStyleSheet("color: white")

        self.label6 = QLabel("NOTIFICATIONS:", self)
        self.label6.setFont(font2)
        self.label6.setGeometry(354,240, 150,20)
        self.label6.setStyleSheet("color: white")

        ###################################################################################################################################################################################

        self.btn1 = QPushButton("Normal", self)
        self.btn1.setFont(font3)
        self.btn1.setGeometry(354,58, 104,40)
        self.btn1.setStyleSheet("""border-radius: 11;
                                  background-color: #0d5550;
                                  color: white;""")
        self.btn1.clicked.connect(self.infood)

        self.btn2 = QPushButton("Vegetarian", self)
        self.btn2.setFont(font3)
        self.btn2.setGeometry(461,58, 104,40)
        self.btn2.setStyleSheet("""border-radius: 11;
                                  background-color: #0d5550;
                                  color: white;""")
        self.btn2.clicked.connect(self.infood)

        self.btn3 = QPushButton("Vegan", self)
        self.btn3.setFont(font3)
        self.btn3.setGeometry(568,58, 104,40)
        self.btn3.setStyleSheet("""border-radius: 11;
                                  background-color: #0d5550;
                                  color: white;""")
        self.btn3.clicked.connect(self.infood)

        self.btn5 = QPushButton("Fridge Contents", self)
        self.btn5.setFont(font3)
        self.btn5.setGeometry(354,145, 318,20)
        self.btn5.setStyleSheet("""border-radius: 11;
                                  background-color: #0d5550;
                                  color: white;""")
        self.btn5.clicked.connect(self.FridgeWindow)

        self.btn6 = QPushButton("Recipies and Food Calculator", self)
        self.btn6.setFont(font3)
        self.btn6.setGeometry(354,205, 318,20)
        self.btn6.setStyleSheet("""border-radius: 11;
                                  background-color: #0d5550;
                                  color: white;""")
        self.btn6.clicked.connect(self.calculator)

        self.btn7 = QPushButton("Eating\nStimulator", self)
        self.btn7.setFont(font3)
        self.btn7.setGeometry(354,265, 104,40)
        self.btn7.setStyleSheet("""border-radius: 11;
                                  background-color: #0d5550;
                                  color: white;""")
        self.btn7.clicked.connect(self.infood)

        self.btn8 = QPushButton("Expired\nSoon", self)
        self.btn8.setFont(font3)
        self.btn8.setGeometry(461,265, 104,40)
        self.btn8.setStyleSheet("""border-radius: 11;
                                  background-color: #0d5550;
                                  color: white;""")
        self.btn8.clicked.connect(self.infood)

        self.btn9 = QPushButton("Meal\nSchedule", self)
        self.btn9.setFont(font3)
        self.btn9.setGeometry(568,265, 104,40)
        self.btn9.setStyleSheet("""border-radius: 11;
                                  background-color: #0d5550;
                                  color: white;""")
        self.btn9.clicked.connect(self.infood)

        self.btn10 = QPushButton("Discord Server", self)
        self.btn10.setFont(font3)
        self.btn10.setGeometry(40,240, 250,40)
        self.btn10.setStyleSheet("""border-radius: 11;
                                  background-color: #0d5550;
                                  color: white;""")
        self.btn10.clicked.connect(self.infood)


    def infood(self):
        print("Pressed!")


    def FridgeWindow(self):
        data = Data()

        widget.addWidget(data)
        widget.setCurrentIndex(widget.currentIndex() + 1)


    def calculator(self):
        calc = Calculator()

        widget.addWidget(calc)
        widget.setCurrentIndex(widget.currentIndex() + 1)

    def notifier(self):
        os.startfile("C:/Users/Ziga/Documents/GitHub/hekaton_2021/Notifier/Notifier.exe")



class Data(QWidget):
    def __init__(self):
        super().__init__()

        conn = sqlite3.connect('hladilnik.db')

        c = conn.cursor()

        c.execute("""CREATE TABLE IF NOT EXISTS addfood (
            name text,
            number integer,
            date text
        )""")

        conn.commit()
        conn.close()

        self.show_all()

        #############################################################################################################################################

        self.font = QFont("OCR A Extended")
        self.font.setPointSize(12)
        self.font.setBold(True)

        self.font1 = QFont("OCR A Extended")
        self.font1.setPointSize(11)
        self.font1.setBold(False)

        self.font2 = QFont("OCR A Extended")
        self.font2.setPointSize(10)
        self.font2.setBold(True)

        #############################################################################################################################################

        self.btn = QPushButton("<-", self)
        self.btn.setFont(self.font)
        self.btn.setGeometry(5,5, 25,20)
        self.btn.setStyleSheet("""color: white;
                                border: 1px solid #505050""")
        self.btn.clicked.connect(self.back)

        #############################################################################################################################################

        self.label = QLabel("FRIDGE CONTENTS:", self)
        self.label.setFont(self.font)
        self.label.setGeometry(90,30, 150,20)
        self.label.setStyleSheet("color: white;")

        self.label1 = QLabel("ADD FOOD", self)
        self.label1.setFont(self.font)
        self.label1.setGeometry(450,30, 150,20)
        self.label1.setStyleSheet("color: white;")

        self.label2 = QLabel("NAME", self)
        self.label2.setFont(self.font)
        self.label2.setGeometry(320,60, 50,20)
        self.label2.setStyleSheet("color: white;")

        self.label3 = QLabel("EXPIR. DATE", self)
        self.label3.setFont(self.font)
        self.label3.setGeometry(320,100, 110,20)
        self.label3.setStyleSheet("color: white;")

        self.label4 = QLabel("QUANTITY", self)
        self.label4.setFont(self.font)
        self.label4.setGeometry(320,140, 85,20)
        self.label4.setStyleSheet("color: white;")

        self.label5 = QLabel("FOOD", self)
        self.label5.setFont(self.font2)
        self.label5.setGeometry(15,55, 40,25)
        self.label5.setStyleSheet("color: white;")

        self.label6 = QLabel("QUANTITY", self)
        self.label6.setFont(self.font2)
        self.label6.setGeometry(112,55, 65,25)
        self.label6.setStyleSheet("color: white;")

        self.label7 = QLabel("EXPIR. DATE", self)
        self.label7.setFont(self.font2)
        self.label7.setGeometry(207,55, 100,25)
        self.label7.setStyleSheet("color: white;")

        #############################################################################################################################################

        self.names = QLineEdit(self)
        self.names.setFont(self.font1)
        self.names.setGeometry(445,60, 230,20)
        self.names.setStyleSheet("""border: 1px solid gray;
                                        color: white""")
        self.dates = QLineEdit(self)
        self.dates.setFont(self.font1)
        self.dates.setGeometry(445,100, 230,20)
        self.dates.setStyleSheet("""border: 1px solid gray;
                                    color: white""")
        self.quantitys = QLineEdit(self)
        self.quantitys.setFont(self.font1)
        self.quantitys.setGeometry(445,140, 230,20)
        self.quantitys.setStyleSheet("""border: 1px solid gray;
                                        color: white;""")

        #############################################################################################################################################

        self.btn1 = QPushButton("Submit", self)
        self.btn1.setFont(self.font1)
        self.btn1.setGeometry(457,190, 70,40)
        self.btn1.setStyleSheet("""border-radius: 11;
                                  background-color: #0d5550;
                                  color: white;""")
        self.btn1.clicked.connect(self.submit)
        self.btn1.clicked.connect(self.show_all)


    def submit(self):
        conn = sqlite3.connect('hladilnik.db')

        c = conn.cursor()

        # Insert Data Into 'addfood' Table
        c.execute("INSERT INTO addfood VALUES (:name, :number, :date)",
            {
                'name': self.names.text(),
                'number': self.quantitys.text(),
                'date': self.dates.text()
            })

        conn.commit()
        conn.close()

        # Clear Input Boxes
        self.names.clear()
        self.quantitys.clear()
        self.dates.clear()


    def show_all(self):
        self.font1 = QFont("OCR A Extended")
        self.font1.setPointSize(10)
        self.font1.setBold(False)

        conn = sqlite3.connect('hladilnik.db')
        c = conn.cursor()

        c.execute("SELECT *, oid FROM addfood")

        records = c.fetchall()

        x = 15
        y = 80

        x1 = 120
        y1 = 35

        i = 0

        for record in records:
            for item in record:
                if i == 3:
                    break

                if i == 0:
                    x1 += 20
                    
                if i == 1:
                    x1 -= 60
                    x += 30

                if i == 2:
                    x1 += 25
                    x -= 20
                    
                else:
                    pass


                self.label5 = QLabel(str(item), self)
                self.label5.setFont(self.font1)
                self.label5.setGeometry(x,y, x1,y1)
                self.label5.setStyleSheet("color: white;")

                x += 95

                i += 1

            x = 15
            y += 35
            x1 = 95
            y1 = 25

            i = 0

        conn.commit()
        conn.close()


    def back(self):
        window = Window()

        widget.addWidget(window)
        widget.setCurrentIndex(widget.currentIndex() + 1)



class Calculator(QWidget):
    def __init__(self):
        super(Calculator, self).__init__()

        font = QFont("OCR A Extended")
        font.setPointSize(12)
        font.setBold(True)

        font1 = QFont("OCR A Extended")
        font1.setPointSize(24)
        font1.setBold(True)

        font2 = QFont("OCR A Extended")
        font2.setPointSize(12)
        font2.setBold(False)

        font3 = QFont("OCR A Extended")
        font3.setPointSize(10)
        font3.setBold(False)

        ##############################################################################################################################################################################

        self.btn = QPushButton("<-", self)
        self.btn.setFont(font)
        self.btn.setGeometry(5,5, 25,20)
        self.btn.setStyleSheet("""border: 1px solid #505050;
                                  color: white;""")
        self.btn.clicked.connect(self.back)

        self.btn1 = QPushButton("Normal", self)
        self.btn1.setFont(font2)
        self.btn1.setGeometry(174,180, 104,40)
        self.btn1.setStyleSheet("""border-radius: 11;
                                   background-color: #0d5550;
                                   color: white;""")
        self.btn1.clicked.connect(self.normal)

        self.btn2 = QPushButton("Vegetarian", self)
        self.btn2.setFont(font3)
        self.btn2.setGeometry(294,180, 104,40)
        self.btn2.setStyleSheet("""border-radius: 11;
                                   background-color: #0d5550;
                                   color: white;""")
        self.btn2.clicked.connect(self.vegetarion)

        self.btn3 = QPushButton("Vegan", self)
        self.btn3.setFont(font2)
        self.btn3.setGeometry(414,180, 104,40)
        self.btn3.setStyleSheet("""border-radius: 11;
                                   background-color: #0d5550;
                                   color: white;""")
        self.btn3.clicked.connect(self.vegan)

        ##############################################################################################################################################################################

        self.label = QLabel("CHOOSE:", self)
        self.label.setFont(font1)
        self.label.setGeometry(280,130, 200,50) 
        self.label.setStyleSheet("color: white;")       

    
    def back(self):
        window = Window()

        widget.addWidget(window)
        widget.setCurrentIndex(widget.currentIndex() + 1)


    def normal(self):
        os.startfile("C:/Users/Ziga/Documents/GitHub/hekaton_2021/Normal/Normal.exe")

    
    def vegetarion(self):
        os.startfile("C:/Users/Ziga/Documents/GitHub/hekaton_2021/Vege/Vege.exe")


    def vegan(self):
        os.startfile("C:/Users/Ziga/Documents/GitHub/hekaton_2021/Vegen/Vegen.exe")



app = QApplication(sys.argv)

widget = QStackedWidget()

window = Window()
widget.addWidget(window)

widget.setStyleSheet("""background-color: #505050;""")
widget.setGeometry(500,300, 700,400)
widget.setWindowIcon(QIcon("C:/Users/Ziga/Downloads/icon.png"))
widget.setWindowTitle("Handy Meal")

widget.show()

sys.exit(app.exec())